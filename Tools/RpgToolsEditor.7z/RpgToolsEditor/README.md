﻿# RpgToolsTshockGUI

RpgToolsTshockGUI is a collection of graphical editors for the plugin data. At the time of this writing, the editors are all housed within a single Winforms application, but may be separated out in future iterations.

# Building

RpgToolsTshockGUI is a standard Windows Forms project. It can be built within Visual Studio 2017, or via commandline by directly invoking msbuild.

